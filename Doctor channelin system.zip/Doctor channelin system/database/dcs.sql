-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 27, 2021 at 05:37 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dcs`
--

-- --------------------------------------------------------

--
-- Table structure for table `appoinmenttable`
--

DROP TABLE IF EXISTS `appoinmenttable`;
CREATE TABLE IF NOT EXISTS `appoinmenttable` (
  `FirstName` varchar(100) NOT NULL,
  `LastName` varchar(100) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `NICnumber` varchar(15) NOT NULL,
  `DoctorName` varchar(100) NOT NULL,
  `NIC_number` varchar(100) NOT NULL,
  `Date` date NOT NULL,
  `MobileNumber` varchar(15) NOT NULL,
  `Email` varchar(100) NOT NULL,
  PRIMARY KEY (`NICnumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appoinmenttable`
--

INSERT INTO `appoinmenttable` (`FirstName`, `LastName`, `Gender`, `NICnumber`, `DoctorName`, `NIC_number`, `Date`, `MobileNumber`, `Email`) VALUES
('piyumi', 'nawarathna', 'Female', '223344556v', 'Dr. minoli de silva', '986543862v', '2021-02-05', '977345678v', 'piyuminawarathna@gmail.com'),
('kumuduni', 'nisansala', 'Female', '975672348v', 'Dr. Rahul Mahendran', '972772596v', '2021-01-30', '0714356789', 'kumuduninisansala@gmail.com'),
('Danushika', 'Amarasinghe', 'Female', '123456778v', 'Dr. Nimali Siriwardana', '123456789v', '2021-01-28', '1234567890', 'danu1997@gmail.com'),
('Jayanga', 'chandeepa', 'male', '972334455v', 'Dr. Nimali Siriwardana', '123456789v', '2021-02-03', '0711483450', 'Jayangachandeepa.11@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `detailstable`
--

DROP TABLE IF EXISTS `detailstable`;
CREATE TABLE IF NOT EXISTS `detailstable` (
  `FirstName` varchar(100) NOT NULL,
  `LastName` varchar(100) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `NICnumber` varchar(15) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `MobileNumber` varchar(15) NOT NULL,
  `Email` varchar(100) NOT NULL,
  PRIMARY KEY (`NICnumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detailstable`
--

INSERT INTO `detailstable` (`FirstName`, `LastName`, `Gender`, `NICnumber`, `Address`, `MobileNumber`, `Email`) VALUES
('Jayanga', 'chandeepa', 'male', '972334455v', 'Gampaha', '0711483450', 'Jayangachandeepa.11@gmail.com'),
('jayanga', 'chandeepa', 'male', '970553053v', 'Gampaha', '0711483450', 'jayangachandeepa.11@gmail.com'),
('jayanga', 'chandeepa', 'male', '972334556v', 'gampaha', '0711483450', 'jayangachandeepa.11@gmail.com'),
('Danushika', 'Amarasinghe', 'Female', '123456987v', 'badulla', '098765432', 'danu1997@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `doctordetails`
--

DROP TABLE IF EXISTS `doctordetails`;
CREATE TABLE IF NOT EXISTS `doctordetails` (
  `FirstName` varchar(100) NOT NULL,
  `LastName` varchar(100) NOT NULL,
  `SpecialAbout` varchar(100) NOT NULL,
  `NICnumber` varchar(15) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `MobileNumber` varchar(15) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `CurrentHospital` varchar(100) NOT NULL,
  PRIMARY KEY (`NICnumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctordetails`
--

INSERT INTO `doctordetails` (`FirstName`, `LastName`, `SpecialAbout`, `NICnumber`, `Address`, `MobileNumber`, `Email`, `CurrentHospital`) VALUES
('Dr. nimal', 'perera', 'eye specialist', '111111159v', 'colombo', '07711223546', 'nimalperera@gmail.com', 'Asiri hospital'),
('Dr. Nimali', 'Siriwardana', 'Skin Specialist', '123456789v', 'Colombo Road, Gampaha', '0714326587', 'nimalisiriwardana@gmail.com', 'Base Hospital Gampaha'),
('Dr. Saman', 'Rathnayake', 'Clincal Oncologist', '223344659v', 'Miriswaththa, Gampaha', '0773648726', 'samanrathnayke@icloud.com', 'Base Hospital Gampaha'),
('Dr. Rahul', 'Mahendran', 'Skin specialist', '972772596v', 'Pasyala Road, Kirindiwela', '0769742385', 'rahulmahendran@yahoo.com', 'Base Hospital Gampaha'),
('Dr. minoli', 'de silva', 'Eye Specialist', '986543862v', '815/A Grandpass, colombo', '0782345812', 'minoeye@gmail.com', 'Asiri hospital');

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
CREATE TABLE IF NOT EXISTS `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nic` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_nic` (`nic`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`id`, `nic`, `date`, `time`, `status`) VALUES
(37, '123456789v', '2021-02-03', '09:00:00', 1),
(47, '123456789v', '2021-02-10', '16:00:00', 1),
(48, '972772596v', '2021-01-30', '20:00:00', 1),
(49, '972772596v', '2021-02-08', '20:00:00', 1),
(51, '223344659v', '2021-01-26', '09:00:00', 1),
(55, '123456789v', '2021-02-17', '09:00:00', 1),
(56, '123456789v', '2021-02-24', '20:00:00', 1),
(57, '223344659v', '2021-02-02', '16:00:00', 1),
(58, '223344659v', '2021-02-16', '16:00:00', 1),
(59, '223344659v', '2021-03-25', '16:02:00', 1),
(60, '972772596v', '2021-03-24', '16:00:00', 1),
(61, '972772596v', '2021-02-20', '09:00:00', 1),
(62, '986543862v', '2021-02-05', '10:00:00', 1),
(63, '986543862v', '2021-02-18', '19:00:00', 1),
(64, '986543862v', '2021-02-26', '19:00:00', 1),
(65, '111111159v', '2021-02-01', '17:00:00', 1),
(67, '111111159v', '2021-02-06', '19:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `staffdetailstable`
--

DROP TABLE IF EXISTS `staffdetailstable`;
CREATE TABLE IF NOT EXISTS `staffdetailstable` (
  `FirstName` varchar(100) NOT NULL,
  `LastName` varchar(100) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `NICnumber` varchar(15) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `MobileNumber` varchar(15) NOT NULL,
  `Email` varchar(100) NOT NULL,
  PRIMARY KEY (`NICnumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staffdetailstable`
--

INSERT INTO `staffdetailstable` (`FirstName`, `LastName`, `Gender`, `NICnumber`, `Address`, `MobileNumber`, `Email`) VALUES
('nalin', 'miththa', 'male', '111111111v', 'welimada', '1234567890', 'nalinmiththa@gmail.com'),
('harsha', 'sadakelum', 'male', '987654321v', 'gampaha', '1234567890', 'rashmiperera@gmail.com'),
('harsha', 'sandakelum', 'male', '970553053v', 'welpalla', '0762270217', 'harshamt402@gmail.com'),
('harsha', 'sandakelum', 'male', '971234567v', 'kuliyapitiya', '0762279217', 'harshamt402@gmail.com'),
('harsha', 'sadakelum', 'male', '123456789v', 'kaduwela', '0112233445', 'harshasadakelum@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `staffid`
--

DROP TABLE IF EXISTS `staffid`;
CREATE TABLE IF NOT EXISTS `staffid` (
  `ID` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `NICnumber` varchar(15) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staffid`
--

INSERT INTO `staffid` (`ID`, `name`, `NICnumber`) VALUES
('s1', 'saman', '987654321v'),
('s3', 'kamal', '123456788v');

-- --------------------------------------------------------

--
-- Table structure for table `stafftable`
--

DROP TABLE IF EXISTS `stafftable`;
CREATE TABLE IF NOT EXISTS `stafftable` (
  `name` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stafftable`
--

INSERT INTO `stafftable` (`name`, `Password`) VALUES
('sandakelum', '12345678'),
('harsha', '55555');

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

DROP TABLE IF EXISTS `usertable`;
CREATE TABLE IF NOT EXISTS `usertable` (
  `Name` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  PRIMARY KEY (`Name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`Name`, `Password`) VALUES
('jck', '11111'),
('chandeepa', '11111');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `info`
--
ALTER TABLE `info`
  ADD CONSTRAINT `fk_nic` FOREIGN KEY (`nic`) REFERENCES `doctordetails` (`NICnumber`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
