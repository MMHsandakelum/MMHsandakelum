 <?php
 
// User login validation part
 
session_start();

require_once "inc/connection2.php";

 mysqli_select_db($con,'dcs');
 $name = $_POST['user'];
 $pass = $_POST['password'];

 $s = "select * from usertable where name = '$name' && password = '$pass'";
 $result = mysqli_query($con, $s);
 $num = mysqli_num_rows($result);

 if($num == 1){
 	$_SESSION['log-status'] = true;
 	header('Location: home.php');
 }else{
 	echo "<script>";
 		echo "alert('Login Failed! Please Try Again')";
 	echo "</script>";
 	header('location: login.php');
 }

 ?>
