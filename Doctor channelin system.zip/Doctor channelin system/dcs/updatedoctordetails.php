<?php 
	require_once "inc/connection2.php";

	session_start();
	$name = "";
	$address = "";
	$id = 0;
	$edit_state = false;

	// insert records

	if (isset($_POST['save'])) {
		print_r($_POST);
		$nic = $_POST['nic'];
		$date = $_POST['date'];
		$time = $_POST['time'];
		$status = $_POST['status'];

		$query = "INSERT INTO info (nic, date,time,status) VALUES ('$nic', '$date' ,'$time','$status')";
		$resu = mysqli_query($con, $query);

		if($resu){
			$_SESSION['msg'] = "Details Saved...!!!";
		}else{
			print_r(mysqli_error($con));
		}
		header('location: inputAvailableDoctors.php?nic='.$_POST['nic']);
	}

	// update records

	if(isset($_POST['update'])) {

		$date = mysqli_real_escape_string($con, $_POST['date']);

		$time = mysqli_real_escape_string($con,$_POST['time']);

		$status = mysqli_real_escape_string($con,$_POST['status']);

		$sql = "UPDATE info SET date='{$date}', time='{$time}',status={$status} WHERE id={$_POST['id']}";

		$ri = mysqli_query($con,$sql);

		$_SESSION['msg'] = "Details Updated...!!!";

		header("location: inputAvailableDoctors.php?nic=" . $_POST['nic']);
	}


	//delete records
	if(isset($_GET['del'])){
		$id = $_GET['del'];
		$nic = $_GET['nic'];
		mysqli_query($con,"DELETE FROM info WHERE id=$id");
		$_SESSION['msg'] = "Details Deleted...!!!";

		header('location: inputAvailableDoctors.php?nic='. $nic);

	}
?>