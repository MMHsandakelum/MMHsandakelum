<?php  
	
	if(!isset($_GET['name'])){
		header('Location:channel.php');
	}
	if(!isset($_GET['id'])){
		header('Location:channel.php');
	}

	$name = $_GET['name'];
	$id = $_GET['id'];

?>

<!DOCTYPE html>

<html>
<head>
	<title>Make an appoinment</title>
	<link rel="stylesheet" type="text/css" href="assets/css/userdetailsstyle.css">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
	<div class="registration-box">
		<div class="crate-account">
			<h2>Appoinment form</h2>
			<form action="appoinmentdb.php" method="post">
				<div class="form-group">
					<input type="hidden" name="id" value="<?php echo $id ?>">
					<label>First Name :</label>
					<input type="text" name="Fname" class="form-control" required>
				</div>

				<div class="form-group">
					<label>Last Name :</label>
					<input type="text" name="Lname" class="form-control" required>
				</div> 

				<div class="form-group">
					<label>Gender :</label>
					<input type="text" name="sex" class="form-control" required>
				</div> 

				<div class="form-group">
					<label>NIC Number :</label>
					<input type="text" name="nic" class="form-control" required>
				</div> 

				<div class="form-group">
					<label>Doctors name :</label>
					<input type="text" name="dname" class="form-control" value="<?php echo $name ?>" readonly>

				</div> 

				<div class="form-group">
					<label>Appoinment Date :</label>
					<input type="Date" name="date" class="form-control" required>
				</div> 

				<div class="form-group">
					<label>Mobile number :</label>
					<input type="text" name="mobilenumber" class="form-control" required>
				</div>

				<div class="form-group">
					<label>E-mail :</label>
					<input type="text" name="Email" class="form-control" required>
				</div> 

				<button type="submit" class="btn btn-primary">Next></button>
				<br>
				<br>
				<a href="home.html"> Back to home</a>
			</form>
		</div>
	</div>
</body>
</html>