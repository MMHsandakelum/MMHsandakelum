<?php 

	require_once '../inc/connection2.php';

	$search = $_POST['search'];

	//getting doctors details
	$query = "SELECT FirstName,LastName FROM doctordetails WHERE concat(FirstName,' ',LastName) LIKE '%{$search}%' ";
	$result= mysqli_query($con,$query);

	if($result){
		if(!empty($search)){

				echo "<ul id='res'>";
			while($sen = mysqli_fetch_assoc($result)){
				echo "<li>".$sen['FirstName']." ".$sen['LastName']."</li>";
			}
			echo "</ul>";

		}
	}


 ?>