<!DOCTYPE html>
<html>
<head>
	<title>Staff Login page</title>
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>

<body>
	<h1>MEDIPLUS Doctor Channeling System</h1>
	<div class="container">
		<div class="login-box">
			<div class="row">
				<div class="col-md-6 login-right">
					<h2>Staff Login Here</h2>
					<form action="staffvalidation.php" method="post">
						<div class="form-group">
							<label>Staff's Username</label>
							<input type="text" name="user" class="form-control" required>
						</div>

						<div class="form-group">
							<label>Staff's Password</label>
							<input type="password" name="password" class="form-control" required>
						</div> 
						
						<button type="submit" class="btn btn-primary">LOGIN</button>
					</form>
					<br>
					<a href="staffidpage.php">Create an account?</a>
				</div>
			</div>
		</div>
	</div>
</body>
</html>