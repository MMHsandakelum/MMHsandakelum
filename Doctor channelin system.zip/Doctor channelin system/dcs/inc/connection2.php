 <?php
 $con = mysqli_connect('localhost','root','JCK.php1','dcs');

 ?>