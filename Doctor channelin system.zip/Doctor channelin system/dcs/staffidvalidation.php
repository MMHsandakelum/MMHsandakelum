 <?php
ob_start();
session_start();

require_once "inc/connection2.php";

 mysqli_select_db($con,'dcs');
 $id = $_POST['Id'];
 $nic = $_POST['nic'];

 $s = "select * from staffid where ID = '$id' && NICnumber = '$nic'";
 $result = mysqli_query($con, $s);
 $num = mysqli_num_rows($result);

 if($num == 1){
 	header('location: staffdetails.php');
 }else{
 	header('location: staffidwarning.php');
 }

 ?>
