 <?php

session_start();
/*header('location: login.php');*/
require_once "inc/connection2.php";

 mysqli_select_db($con,'dcs');
 $name = $_POST['user'];
 $pass = $_POST['password'];

 $s = "select * from usertable where name = '$name'";
 $result = mysqli_query($con, $s);
 $num = mysqli_num_rows($result);

 if($num == 1){
 	header("refresh:0; url=usernamewarning.php");
 }else{
 	$reg = "insert into usertable (Name, Password) values ('$name', '$pass')";
 	mysqli_query($con, $reg);
 	
 	header("refresh:0; url=success.php");
 }

 ?>
