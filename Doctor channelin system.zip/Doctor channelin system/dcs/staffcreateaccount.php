<!DOCTYPE html>
<html>
<head>
	<title>User Registration</title>
	<link rel="stylesheet" type="text/css" href="assets/css/userdetailsstyle.css">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
	<div class="registration-box">
		<div class="crate-account">
			<h2>Register Here (Staff)</h2>
			<form action="staffregistration.php" method="post">
				<div class="form-group">
					<label>Username (For create an account) :</label>
					<input type="text" name="user" class="form-control" required>
				</div>

				<div class="form-group">
					<label>Your Password :</label>
					<input type="password" name="password" class="form-control" required>
				</div> 

				<button type="submit" class="btn btn-primary">Register</button>
			</form>
		</div>
	</div>
</body>
</html>