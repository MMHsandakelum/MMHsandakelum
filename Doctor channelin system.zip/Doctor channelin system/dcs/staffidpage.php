<!DOCTYPE html>
<html>
<head>
	<title>Staff Verification</title>
	<link rel="stylesheet" type="text/css" href="assets/css/userdetailsstyle.css">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
	<div class="registration-box">
		<div class="crate-account">
			<h5>Enter your staff id provide by the company and the NIC number here.</h5>
			<br>
			<form action="staffidvalidation.php" method="post">
				<div class="form-group">
					<label>Staff id :</label>
					<input type="text" name="Id" class="form-control" required>
				</div>

				<div class="form-group">
					<label>NIC Number :</label>
					<input type="text" name="nic" class="form-control" required>
				</div>

				<button type="submit" class="btn btn-primary">Next></button>
			</form>
		</div>
	</div>
</body>
</html>