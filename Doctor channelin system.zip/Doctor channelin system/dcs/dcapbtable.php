<?php  
	require_once "inc/connection2.php";	
	$dr = '';

	$nic = $_GET["nic"];
	if(!isset($_GET["nic"])){
		header('Location:viewappoinment.php');
	}
	else{
		$sql = "SELECT * FROM appoinmenttable WHERE NIC_number = '{$nic}'";
		$result = mysqli_query($con,$sql);

		if(!$result){
			print_r(mysqli_error($con));
		}
	}

	if(!isset($_GET['drnam'])){
		header('Location:viewappoinment.php');
	}
	else{
		$drname = $_GET['drnam'];
	}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="assets/css/main.css" />
</head>
<style>
	*{
		padding: 0;
		margin: 0;
		box-sizing: border-box;
	}
	body{
		margin: 0;
		padding: 0;
	}
	.pg_top{
		padding: 55px 0;
		display: flex;
		justify-content: center;
		align-items: center;
		margin-bottom: 40px;
		background: linear-gradient(to right,#45ad97,#e0ffbd);
	}
	.pg_top h1{
		font-size: 40px;
		text-transform: capitalize;
		margin: 0;
		color: #463d3d;
	}
	.table{
		width: 80%;
		margin: auto;
	}
</style>
<body>
	<div class="pg_top">
		<h1><?php echo $drname; ?></h1>
	</div>
	<div class="table">
		<?php if(mysqli_num_rows($result) > 0){ ?>
		<div class="table-wrapper">
			<table>
				<thead>
					<tr>
						<th>Name</th>
						<th>Gender</th>
						<th>NIC Number</th>
						<th>Date</th>
						<th>Mobile</th>
						<th>Email</th>
					</tr>
				</thead>
				<tbody>
					<?php  
						if(mysqli_num_rows($result) > 0){
							while ($dl = mysqli_fetch_assoc($result)) {
								echo "<tr>";
									echo "<td>".$dl['FirstName']." ".$dl['LastName']."</td>";
									echo "<td>".$dl['Gender']."</td>";
									echo "<td>".$dl["NICnumber"]."</td>";
									echo "<td>".$dl["Date"]."</td>";
									echo "<td>".$dl["MobileNumber"]."</td>";
									echo "<td>".$dl["Email"]."</td>";
								echo "</tr>";
							}
						}
					?>
				</tbody>
			</table>
		</div>
	<?php }else{
		echo "<div class='nam'>";
			echo "<h2>No Available Appoinmets </h2>";
		echo "</div>";
	} ?>
	</div>
</body>
</html>