 <?php

session_start();
	if($_SESSION["staff-status"] !== true){
		if($_SESSION["staff-status"]){
			session_destroy();
		}print_r($_SESSION);
		header('Location: stafflogin.php');
	}

require_once "inc/connection2.php";

 mysqli_select_db($con,'dcs');
 $fname = $_POST['Fname'];
 $lname = $_POST['Lname'];
 $spec = $_POST['special'];
 $nic = $_POST['nic'];
 $addr = $_POST['address'];
 $mobile = $_POST['mobilenumber'];
 $mail = $_POST['Email'];
 $hospital = $_POST['hospital'];

 $s = "select * from doctordetails where NICNumber = '$nic'";
 $result = mysqli_query($con, $s);
 $num = mysqli_num_rows($result);

  if($num == 1){
  	echo "Id Is already Taken";
 }else{
 	$regi = "insert into doctordetails (FirstName, LastName, SpecialAbout, NICnumber, Address, MobileNumber, Email, CurrentHospital) 
	values ('$fname', '$lname', '$spec', '$nic', '$addr', '$mobile', '$mail', '$hospital')";
	mysqli_query($con, $regi);

	header("refresh:0; url=Staffhome.php");

 }

 ?>
