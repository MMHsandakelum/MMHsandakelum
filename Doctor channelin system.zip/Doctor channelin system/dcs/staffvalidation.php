 <?php

session_start();

require_once "inc/connection2.php";

 mysqli_select_db($con,'dcs');
 $name = $_POST['user'];
 $pass = $_POST['password'];

 $s = "select * from stafftable where name = '$name' && password = '$pass'";
 $result = mysqli_query($con, $s);
 $num = mysqli_num_rows($result);

 if($num == 1){
 	$_SESSION["staff-status"] = true;
 	header('location: Staffhome.php');
 }else{
 	header('location: stafflogin.php');
 }

 ?>
