<?php ; 

	if (isset($_GET['edit'])) {
		$id = $_GET['edit'];
		$edit_state = true;
		$rec = mysqli_query($db, "SELECT * FROM appoinmenttable");
		$record = mysqli_fetch_array($rec);
		$name = $record['DoctorName'];
		$address = $record['Date'];
		$pname = $record['FirstName'];
		$phonenum = $record['MobileNumber'];
		$email = $record['Email'];
	}	

?>
<?php  
	require_once "inc/connection2.php";

	session_start();

	$doctor_result = "";
	$doctor_count = false;

	if($_SESSION['staff-status'] !== true){
		header('Location:stafflogin.php');
	}else{

		$sql = "SELECT nicnumber,firstname,lastname,specialabout FROM doctordetails";
		$result = mysqli_query($con,$sql);

		if($result){
			if(mysqli_num_rows($result) > 0){
				$doctor_count = true;
			}
		}
	}
?>
<!DOCTYPE html>
<!--
-->
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<title>Appoinment details</title>
	<link href="default.css" rel="stylesheet" type="text/css" media="all" />
	<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" type="text/css" href="CSS/updatestyle3.css">
	<link rel="stylesheet" href="assets/css/availabletc.css">

</head>
<body>

<div class="card_body">
		<div class="top_header">
			<h1>Appoinment List</h1>
		</div>
	<div class="main_ca">
		<?php  

			if($doctor_count != false){ ?>

				<?php  

					while ($doctor_result = mysqli_fetch_assoc($result)) { ?>
						<div class="card">
							<a href='dcapbtable.php?nic=<?php echo $doctor_result["nicnumber"]; ?>&drnam=<?php echo $doctor_result["firstname"]; ?> <?php echo $doctor_result["lastname"]; ?>'>
								<div class="name">
									<h2><?php echo $doctor_result['firstname']." ".$doctor_result['lastname']; ?></h2>
								<h3><?php echo $doctor_result['specialabout'] ?></h3>
							</div>
						</a>
					</div>
				<?php }

			?>

					
		<?php 
			}

		?>
	</div>
</div>

<div id="copyright" class="container">
	<p>&copy; Untitled. All rights reserved. | Binary Beast Groups.</p>
</div>
</body>
</html>
