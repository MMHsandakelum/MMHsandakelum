<?php
	session_start();
	if($_SESSION["staff-status"] !== true){
		if($_SESSION["staff-status"]){
			session_destroy();
		}print_r($_SESSION);
		header('Location: stafflogin.php');
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Home Page (Staff)</title>
	<link rel="stylesheet" type="text/css" href="css/staffhome.css">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="assets/css/style2.css">
</head>
<body>
	<div class="card_body">
		<div class="top_header">
			<h1>Staff Homepage</h1>
		</div>
		<center>
	<br>
	<h2><a href="avalibleDoctorsTa.php" style="text-decoration: none;">Click to Update doctor details</a></h2>
	<br>
	<h2><a href="viewappoinment.php"style="text-decoration: none;">This Month Appoinments</a></h2>
	<br>
	<h2><a href="doctordetails.html"style="text-decoration: none;">Click to doctors Register here</a></h2>
	<br>
	<h3><a href="stafflogout.php" style="text-decoration: none;"><-Logout</a></h3> 
	</center>
	</div>
</body>
</html>