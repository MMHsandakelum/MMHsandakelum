 <?php

ob_start();
session_start();

require_once "inc/connection2.php";

 mysqli_select_db($con,'dcs');
 $fname = $_POST['Fname'];
 $lname = $_POST['Lname'];
 $gend = $_POST['sex'];
 $pnic = $_POST['nic'];
 $dname = $_POST['dname'];
 $did = $_POST['id'];
 $adate = $_POST['date'];
 $mobile = $_POST['mobilenumber'];
 $mail = $_POST['Email'];


 	$regi = "insert into appoinmenttable (FirstName, LastName, Gender, NICnumber, DoctorName, NIC_number, Date, MobileNumber, Email) 
	values ('$fname', '$lname', '$gend', '$pnic', '$dname', '$did', '$adate', '$mobile', '$mail')";
	$result = mysqli_query($con, $regi);


	if($result){

		$to = $mail;
		$mail_subcject = "Message From Online Doctor Channeling System.<br>" ;
		$email_body = "<b>Appointment Successful</b>" ;
		$email_body .= "<b>Name:</b> " . $fname ."<br>";
		$email_body .= "<b>Date:</b> " . $adate ."<br>";
		$email_body .= "<b>Doctor's Name:</b> " . $dname ."<br>";
		$email_body .= "solution.3d.lk@gmail.com" ;

		$header = "solution.3d.lk@gmail.com \r\ncontent-type : text/html;";

		$mail_is = mail($to, $mail_subcject, $email_body,$header);

		if($mail_is){
			echo "Appoinment successful...";
		}
		else{
			echo "<script>";
				echo "alert('Please Try Again!')";
			echo "<script>";
		}
	}
	else{
		print_r(mysqli_error($con));
	}


	header("refresh:3; url=appoinment.php");




 ?>
