<?php  
	require_once "inc/connection2.php";

	session_start();
	if($_SESSION["staff-status"] !== true){
		if($_SESSION["staff-status"]){
			session_destroy();
		}print_r($_SESSION);
		header('Location: stafflogin.php');
	}

	$doctor_result = "";
	$doctor_count = false;

	if($_SESSION['staff-status'] !== true){
		header('Location:stafflogin.php');
	}else{

		$sql = "SELECT nicnumber,firstname,lastname,specialabout FROM doctordetails";
		$result = mysqli_query($con,$sql);

		if($result){
			if(mysqli_num_rows($result) > 0){
				$doctor_count = true;
			}
		}
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="assets/css/availabletc.css">
	<title>Available Doctors</title>
</head>
<body>
	<div class="card_body">
		<div class="top_header">
			<h1>Doctors List</h1>
		</div>
		<div class="main_ca">
			<?php  

				if($doctor_count != false){ ?>

					<?php  

						while ($doctor_result = mysqli_fetch_assoc($result)) { ?>
							<div class="card">
								<a href=<?php echo "inputAvailableDoctors.php?nic={$doctor_result['nicnumber']}" ?>>
									<div class="name">
										<h2><?php echo $doctor_result['firstname']." ".$doctor_result['lastname']; ?></h2>
										<h3><?php echo $doctor_result['specialabout'] ?></h3>
									</div>
								</a>
							</div>
						<?php }

					?>

					
			<?php 
				}

			?>
		</div>
	</div>
</body>
</html>