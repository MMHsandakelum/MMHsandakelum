<?php
	session_start();
	if($_SESSION["log-status"] !== true){
		if($_SESSION["log-status"]){
			session_destroy();
		}
		header('Location: login.php');
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>MEDIPLUS - Homepage</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="landing">

		<!-- Header -->
			<header id="header" class="alt">
				<h1><a href="home.php">MEDIPLUS</a></h1>
				<a href="#nav">Menu</a>
			</header>

		<!-- Nav -->
			<nav id="nav">
				<ul class="links">
					<li><a href="home.php">Home</a></li>
					<li><a href="contactus.html">Contact Us</a></li>
					<li><a href="logout.php">Log Out</a></li>
				</ul>
			</nav>

		<!-- Banner -->
			<section id="banner">
				<h2>Welcome to MEDIPLUS</h2>
				<p>Meet your Doctor on-click</p>
				<ul class="actions">
					<li><a href="channel.php" class="button big special">Chanel here</a></li>
				</ul>
			</section>

		

		<!-- Main -->
			<section id="main" class="wrapper">
				<div class="container">

					<header class="major special">
						<h2>About MEDIPLUS</h2>
						<p1>A physician is not angry at the intemperance of a mad patient, nor does he take it ill to be railed at by a man in fever. Just so should a wise man treat all mankind, as a physician does his patient, and look upon them only as sick and extravagant.</p1>
					</header>

					<a href="#" class="image fit"><img src="images/pic11.jpg" alt="" /></a>
					<section>
						<p>To maintain exceptional and compassionate quality .we are offering cost effective healthcare solutions of private standards .As a socially responsible .healthcare provider ,we are committed to protective our environment .we are committed to meeting the legal and statutory requirements for environmental protection and will continue to work with our staff,subcontractors and the general public whatever possible and continue to work to minimize all adverse effects of our activities on environmental today</p>
						<P>In all our endeavors, we use leadership, innovation, compassion, knowledge, skills and ability to serve our organization,We and others are committed to being responsible for actions, attitudes and high performance standards to achieve positive results.</P>
					</section>
				</div>
			</section>

		<!-- Footer -->
			<footer id="footer">
				<div class="inner">
					<ul class="icons">
						<li><a href="#" class="icon fa-facebook">
							<span class="label">Facebook</span>
						</a></li>
						<li><a href="#" class="icon fa-twitter">
							<span class="label">Twitter</span>
						</a></li>
						<li><a href="#" class="icon fa-instagram">
							<span class="label">Instagram</span>
						</a></li>
						<li><a href="#" class="icon fa-linkedin">
							<span class="label">LinkedIn</span>
						</a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled.</li>
						<li>All rights reserved. | Binary Beast Groups.</li>
					</ul>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>