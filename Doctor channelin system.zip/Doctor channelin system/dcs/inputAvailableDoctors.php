<?php 

include('updatedoctordetails.php');
require_once "inc/connection2.php";

	$doc = false;

	if($_SESSION['staff-status'] !== true){
		header('Location:stafflogin.php');
	}else{

		if(!isset($_GET['nic'])){
			if(!isset($_GET['edit'])){
				header('Location:avalibleDoctorsTa.php');
			}
		}
		else if(isset($_GET['nic'])){
			$nic = $_GET['nic'];

			$sql = "SELECT * FROM info WHERE nic = '{$nic}'";
			$result = mysqli_query($con,$sql);
			if($result){
				if(mysqli_num_rows($result) > 0){
					$doc = true;
				}
				else{
					$doc = false;
				}
			}
			//for name
			$sql1 = "SELECT firstname,lastname FROM doctordetails WHERE nicnumber = '{$nic}'";
			$result1 = mysqli_query($con,$sql1);
			if($result1){
				if(mysqli_num_rows($result1) > 0){
					$fi_result1 = mysqli_fetch_assoc($result1);
				}
			}
			else{
				print_r(mysqli_error($con));
				$fi_result1 = "";
			}
		}

		$us = "";
		if(isset($_GET['edit'])){
			$id = $_GET['edit'];
			$sql = "SELECT * FROM info WHERE id={$id}";
			$res = mysqli_query($con,$sql);

			if($res){
				if(mysqli_num_rows($res) > 0){
					$us = mysqli_fetch_assoc($res);
				}
			}
		}
	}



?>
<!DOCTYPE html>
<html>
<head>
	<title>Available doctors</title>
	<link rel="stylesheet" type="text/css" href="assets/css/updatestyle.css">
</head>
<body>

	<?php if (isset($_SESSION['msg'])): ?>
		<div class="msg">
			<?php  
				echo $_SESSION['msg'];
				unset($_SESSION['msg']);
			?>
		</div>
	<?php endif  ?>

			<div class="name">
				<h2><?php echo $fi_result1['firstname'] . ' '.$fi_result1['lastname'] ?></h2>	
			</div>
	<?php  

		if($doc==true || isset($_GET['edit'])){ ?>


			<table>
				<thead>
					<tr>
						<th>Available Date</th>
						<th>Available Time</th>
						<th>Status</th>
						<th colspan="2">Action</th>
					<tr>
				</thead>

				<tbody>

					<?php while ($row = mysqli_fetch_array($result)) { ?>
						<tr>
							<td><?php echo $row ['date']; ?></td>
							<td><?php echo $row ['time']; ?></td>
							<td><?php if($row ['status'] == 1){echo "Available";}else{echo "Unavailable";} ?></td>
							<td>
								<a class="edit_btn" href="inputAvailableDoctors.php?nic=<?php echo $nic; ?>&edit=<?php echo $row['id']; ?>">Edit</a>
							</td>
							<td>
								<a class="del_btn" href="inputAvailableDoctors.php?del=<?php echo $row['id']; ?>&nic=<?php echo $nic; ?>">Delete</a>
							</td>
						</tr>
					<?php }?>

				</tbody>
			</table>

		<?php
	}

	?>

	<form method="post" action="updatedoctordetails.php">
		<div class="input-group">	
			<input type="hidden" name="nic" value="<?php if(isset($_GET['nic'])){ echo $_GET['nic'];} ?>">	
			<input type="hidden" name="id" value="<?php if(isset($_GET['edit'])){ echo $_GET['edit'];} ?>">	
		</div>

		<div class="input-group">
			<label>Available Date</label>
			<input type="date" name="date" value="<?php if(isset($us['date'])){echo $us['date'];}?>" required>
		</div>

		<div class="input-group">
			<label>Available Time</label>
			<input type="time" name="time" value="<?php if(isset($us['time'])){echo $us['time'];} ?>" required>
		</div>
		
		<div class="input-group">
			<label>Available Status</label>
			<select name="status" required>
				<option hidden value="<?php if(isset($us['status'])){echo $us['status'];}else{echo"";} ?>"><?php if(isset($us['status'])){
					if($us['status'] == 1){echo "Available";}else{echo'Unavailable';}}else{echo "Choose Status";} ?></option>
				<option value="1">Available</option>
				<option value="0">Unavailable</option>
			</select>
		</div>

		<div class="input-group">
			<?php  if (!isset($_GET['edit'])): ?>
				<button type="submit" name="save" class="btn"> Save</button>
			<?php  else: ?>
				<button type="submit" name="update" class="btn"> Update</button>
			<?php  endif ?>
		</div>
		<a href="Staffhome.php"><-Back</a>
	</form>
</body>
</html>