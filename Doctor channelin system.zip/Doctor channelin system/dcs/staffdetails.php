<!DOCTYPE html>
<html>
<head>
	<title>User Registration</title>
	<link rel="stylesheet" type="text/css" href="assets/css/userdetailsstyle.css">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
	<div class="registration-box">
		<div class="crate-account">
			<h2>Register Here (Staff)</h2>
			<form action="staffdetailsdb.php" method="post">
				<div class="form-group">
					<label>First Name :</label>
					<input type="text" name="Fname" class="form-control" required>
				</div>

				<div class="form-group">
					<label>Last Name :</label>
					<input type="text" name="Lname" class="form-control" required>
				</div> 

				<div class="form-group">
					<label>Gender :</label>
					<input type="text" name="sex" class="form-control" required>
				</div> 

				<div class="form-group">
					<label>NIC Number :</label>
					<input type="text" name="nic" class="form-control" required>
				</div> 

				<div class="form-group">
					<label>Address :</label>
					<input type="text" name="address" class="form-control" required>
				</div> 

				<div class="form-group">
					<label>Mobile number :</label>
					<input type="text" name="mobilenumber" class="form-control" required>
				</div>

				<div class="form-group">
					<label>E-mail :</label>
					<input type="text" name="Email" class="form-control" required>
				</div> 

				<button type="submit" class="btn btn-primary">Next></button>
			</form>
		</div>
	</div>
</body>
</html>