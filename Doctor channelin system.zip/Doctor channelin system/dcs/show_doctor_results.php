<?php ob_start() ?>
<?php  

	require_once('inc/connection2.php');

	$doctor_name = $_GET['doctor_name'];
	$catogary = $_GET['categorysp']; 

	if ($doctor_name == '') {
		$doctor_name = '';
	}
	else{
		$doctor_name = '%'.$doctor_name.'%';
	}

	$doctodl = ""; 

	$query = "SELECT * FROM doctordetails WHERE concat(FirstName,' ',LastName) LIKE '$doctor_name' OR SpecialAbout = '{$catogary}' ORDER BY FirstName ASC";
	$result= mysqli_query($con,$query);

	
?>

<!DOCTYPE HTML>

<html>
	<head>
		<title>MEDIPLUS Doctor's Results</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body>

		<!-- Header -->
			<header id="header" class="skel-layers-fixed">
				<h1><a href="home.php">MEDIPLUS</a></h1>
				<a href="#nav">Menu</a>
			</header>

		<!-- Nav -->
			<nav id="nav">
				<ul class="links">
					<li><a href="home.php">Home</a></li>
					<li><a href="contactus.html">Contact Us</a></li>
					<li><a href="logout.php">Log Out</a></li>
				</ul>
			</nav>

		<!-- Main -->
			<section id="main" class="wrapper">
				<div class="container">
					<header class="major special">
						<h2>Doctor's Results</h2>
					</header>

					
					<!-- Table -->
						<section>
							<?php  

								if($result){
									if(mysqli_num_rows($result)>0){
										while ($dr=mysqli_fetch_assoc($result)) { ?>
											<div class="card mb-3" style="max-width: 1200px;border: 2px solid #ABABAB;display: flex;">
							  					<div class="row no-gutters" style="display: flex;flex: 2">
							    					<div class="col-md-4" style="display: flex;justify-content: center;text-align: center;flex-direction: column;width: 300px;height: 270px">
							    						<div class="ig">
							      							<img src="./images//pic04.png" class="card-img" alt="..." style="width: 210px">
							    						</div>
							      						<center>
							      						<div class="col-md-8">
								      						<div class="card-body">
								        						<h3 class="card-title" style="margin:0"><?php echo $dr["FirstName"] ." ".$dr["LastName"]; ?></h3>
								        						<p style="margin-bottom: 1px;font-size: 15px"><?php echo $dr["SpecialAbout"] ?></p>
								        						<p style="margin-bottom: 1px;font-size: 15px"><?php echo $dr["CurrentHospital"] ?></p>
								      						</div>
							    						</div>
							    					</center>
							    					</div>
							    					<div class="table-wrapper" style="flex: 1;height: 100%;max-height: 320px; overflow-y: auto;padding-top: 5px">
							    						<?php  
							    							$nic = $dr['NICnumber'];
							    							$table = "SELECT * FROM info WHERE nic = '{$nic}'";
							    							$resul = mysqli_query($con,$table);

							    							if($resul){
							    								if(mysqli_num_rows($resul) > 0){ ?>
																	<table style="width: 100%; overflow: initial;">
																		<thead>
																			<tr style="">
																				<th style="background-color: #51baa4;color:#fff;position: sticky;top: 0">Date</th>
																				<th style="background-color: #51baa4;color:#fff;position: sticky;top: 0">Time</th>
																				<th style="background-color: #51baa4;color:#fff;position: sticky;top: 0">Status</th>
																			</tr>
																		</thead>
																		<tbody>
															<?php
							    									while ($d = mysqli_fetch_assoc($resul)) {
																		echo "<tr>";
																			echo "<td>".$d['date']."</td>";
																			echo "<td>".$d['time']."</td>";
																			echo "<td>";
																				if($d['status'] == 1){
																					echo "Available";
																				}
																				else{
																					echo "Unavailable";
																				}
																			echo"</td>";
																		echo"</tr>";
							    										
							    									} ?>
																	</tbody>
																</table>
							    							<?php
							    								}
							    							}

							    							
							    						?>
																
													</div>
							  					</div>
							  					<div class="but" style="display: flex;justify-content: center;align-items: center;flex:0.5;padding-right: 10px">
							  						<a href="appoinment.php?id=<?php echo $dr['NICnumber']?>&name=<?php echo $dr['FirstName'] . ' ' . $dr['LastName'] ?>" class="button alt" style="font-size: 14px;">Make an appointmet</a>
							    				</div>	
											</div>
											<br>
										<?php
										}
									}
									else{
										echo "NO selected name or Special type...!!";
									}
								}

							?>
						</section>
				</div>
			</section>

		<!-- Footer -->
			<footer id="footer">
				<div class="inner">
					<ul class="icons">
						<li><a href="#" class="icon fa-facebook">
							<span class="label">Facebook</span>
						</a></li>
						<li><a href="#" class="icon fa-twitter">
							<span class="label">Twitter</span>
						</a></li>
						<li><a href="#" class="icon fa-instagram">
							<span class="label">Instagram</span>
						</a></li>
						<li><a href="#" class="icon fa-linkedin">
							<span class="label">LinkedIn</span>
						</a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled.</li>
						<li>All rights reserved. | Binary Beast Groups.</li>
					</ul>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>