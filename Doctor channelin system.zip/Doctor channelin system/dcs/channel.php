<?php ob_start(); ?>
<?php  
	require_once "inc/connection2.php";

	$query = "SELECT DISTINCT(SpecialAbout) FROM doctordetails";
	$result = mysqli_query($con,$query);

?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>MEDIPLUS chanelling page</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<style>
		#view{
			width: 100%;
			border: 1px solid #eee;
			margin-top: 2px;
			display: none;
		}
		#view ul{
			margin: 0;
			padding: 0;
		}
		#view ul li{
			list-style: none;
			cursor: pointer;
			padding: 5px;
			transition: 0.3s ease;
		}
		#view ul li:hover{
			background-color: #eee;
		}
		.actions{
			margin-top: 25px;
		}
	</style>
	<body>

		<!-- Header -->
			<header id="header">
				<h1><a href="home.php">Mediplus</a></h1>
				<a href="#nav">Menu</a>
			</header>

		<!-- Nav -->
			<nav id="nav">
				<ul class="links">
					<li><a href="home.php">Home</a></li>
					<li><a href="contactus.html">Contact Us</a></li>
					<li><a href="logout.php">Log Out</a></li>
				</ul>
			</nav>

		<!-- Main -->
			<section id="main" class="wrapper">
				<div class="container">

					<header class="major special">
						<h2>Doctor Chanelling form</h2>
					</header>
					<section>
						<h3>Search by name</h3>
						<header class="major special">
							<form method="GET" action="show_doctor_results.php">
								<div class="row uniform 50%">
									<div class="12u$">
										<input type="text" name="doctor name" value="" id="category">
										<div id='view'></div>	
									</div>
								</div>
						</header>
						
					</section>

					<section>
						<h3>Search by Specialization</h3>
						<header class="major special">
								<div class="row uniform 50%">
									<div class="12u$">
										<div class="select-wrapper">
											<?php
												if($result){
													echo '<select name="categorysp" id="categorysp">';
															if(mysqli_num_rows($result)>0){
																echo '<option value="">- Any Specialization -</option>';
																while ($ad = mysqli_fetch_assoc($result)) {
																	echo '<option value="'.$ad['SpecialAbout'].'">'.ucwords(strtolower($ad['SpecialAbout'])).'</option>';
																}
															}
															else{
																echo '<option value="">- No Doctors -</option>';
															}
													echo '</select>';
												}
											?>
											
										</div>
									</div>
								</div>
								<ul class="actions">
									<button type="submit" class="button special">Search</button>
								</ul>
							</form>
						</header>
					</section>
			</section>
		

		<!-- Footer -->
			<footer id="footer">
				<div class="inner">
					<ul class="icons">
						<li><a href="#" class="icon fa-facebook">
							<span class="label">Facebook</span>
						</a></li>
						<li><a href="#" class="icon fa-twitter">
							<span class="label">Twitter</span>
						</a></li>
						<li><a href="#" class="icon fa-instagram">
							<span class="label">Instagram</span>
						</a></li>
						<li><a href="#" class="icon fa-linkedin">
							<span class="label">LinkedIn</span>
						</a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled.</li>
						<li>All rights reserved. | Binary Beast Groups.</li>
					</ul>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

			<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script><!-- jquery cdn -->

			<script>

				$(window).on("keyup", function(){
					var valu = $('#category').val();
					$.post('ajax/doctor_details',{
						search: valu
					},
						function(data){
							$('#view').html(data);
							$('#view').show();
						});
				});
			</script>

			<script>
				//select result
				const box = document.querySelector('#view');
				const textbox = document.querySelector('#category');
				const view = document.querySelector('#view');

				box.addEventListener('click',function(e){
					//select list
					let select = e.target.innerText;
					textbox.value='';
					textbox.value=select;
					view.style.display = 'none';
					textbox.setAttribute('value',select);
				});

			</script>

	</body>
</html>