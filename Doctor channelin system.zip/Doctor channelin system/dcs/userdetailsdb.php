 <?php

session_start();


require_once "inc/connection2.php";

 mysqli_select_db($con,'dcs');
 $fname = $_POST['Fname'];
 $lname = $_POST['Lname'];
 $gend = $_POST['sex'];
 $nic = $_POST['nic'];
 $addr = $_POST['address'];
 $mobile = $_POST['mobilenumber'];
 $mail = $_POST['Email'];

 $s = "select * from detailstable where NICnumber = '$nic'";
 $result = mysqli_query($con, $s);
 $num = mysqli_num_rows($result);

  if($num == 1){
  	header("refresh:0; url=takenidwarning.php");
 }else{
 	$regi = "insert into detailstable (FirstName, LastName, Gender, NICnumber, Address, MobileNumber, Email) 
	values ('$fname', '$lname', '$gend', '$nic', '$addr', '$mobile', '$mail')";
	mysqli_query($con, $regi);

	header("refresh:0; url=idok.php");

 }

 ?>
