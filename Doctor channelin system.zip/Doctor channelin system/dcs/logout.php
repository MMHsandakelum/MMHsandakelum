<?php 
	session_start();
	$_session = array();

	if(isset($_cookie[session_name()])){
		setcookie(session_name(), '' , time() - 86400, '/');
	}

	session_destroy();
	header("location: login.php");

?>